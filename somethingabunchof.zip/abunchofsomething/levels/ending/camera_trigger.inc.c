// Replace the level specific camera volume struct in src/game/camera.c with this.
// Make sure to also add the struct name to the LEVEL_DEFINE in levels/level_defines.h.
struct CameraTrigger sCamEnding[] = {
	NULL_TRIGGER
};