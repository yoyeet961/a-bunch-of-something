#include "levels/ending/area_1/collision.inc.c"
#include "levels/ending/area_1/macro.inc.c"
#include "levels/ending/area_1/spline.inc.c"
#include "levels/ending/model.inc.c"
