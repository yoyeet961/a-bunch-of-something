#include "levels/ending/area_1/geo.inc.c"
