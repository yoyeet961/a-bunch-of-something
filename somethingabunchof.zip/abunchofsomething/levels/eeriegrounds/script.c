#include <ultra64.h>
#include "sm64.h"
#include "behavior_data.h"
#include "model_ids.h"
#include "seq_ids.h"
#include "dialog_ids.h"
#include "segment_symbols.h"
#include "level_commands.h"

#include "game/level_update.h"

#include "levels/scripts.h"


/* Fast64 begin persistent block [includes] */
/* Fast64 end persistent block [includes] */

#include "make_const_nonconst.h"
#include "levels/eeriegrounds/header.h"

/* Fast64 begin persistent block [scripts] */
/* Fast64 end persistent block [scripts] */

const LevelScript level_eeriegrounds_entry[] = {
	INIT_LEVEL(),
	LOAD_MIO0(0x7, _eeriegrounds_segment_7SegmentRomStart, _eeriegrounds_segment_7SegmentRomEnd), 
	ALLOC_LEVEL_POOL(),
	MARIO(MODEL_MARIO, 0x00000001, bhvMario),

	/* Fast64 begin persistent block [level commands] */
	/* Fast64 end persistent block [level commands] */

	AREA(2, eeriegrounds_area_2),
		WARP_NODE( 0x1E, LEVEL_CASTLE_GROUNDS,   0x01,   0x1E, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x14, LEVEL_CASTLE_GROUNDS,   0x01,   0x14, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x0A, LEVEL_CASTLE_GROUNDS,   0x01,   0x0A, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x08, LEVEL_CASTLE_GROUNDS,   0x01,   0x08, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x07, LEVEL_CASTLE_GROUNDS,   0x01,   0x07, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x06, LEVEL_CASTLE_GROUNDS,   0x01,   0x06, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x05, LEVEL_VCUTM,   0x01,   0x0A, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x04, LEVEL_CASTLE_GROUNDS,   0x01,   0x04, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x03, LEVEL_CASTLE_GROUNDS,   0x01,   0x03, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x02, LEVEL_CASTLE,   0x03,   0x02, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x01, LEVEL_CASTLE,   0x01,   0x01, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x00, LEVEL_CASTLE,   0x01,   0x00, WARP_NO_CHECKPOINT),
		WARP_NODE( 0xF1, LEVEL_CASTLE_GROUNDS,   0x01,   0x03, WARP_NO_CHECKPOINT),
		TERRAIN(eeriegrounds_area_2_collision),
		MACRO_OBJECTS(eeriegrounds_area_2_macro_objs),
		SET_BACKGROUND_MUSIC(0x00, SEQ_LEVEL_SPOOKY),
		TERRAIN_TYPE(TERRAIN_GRASS),
		/* Fast64 begin persistent block [area commands] */
		/* Fast64 end persistent block [area commands] */
	END_AREA(),

	AREA(1, eeriegrounds_area_1),
		WARP_NODE( 0x1E, LEVEL_CASTLE_GROUNDS,   0x01,   0x1E, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x14, LEVEL_CASTLE_GROUNDS,   0x01,   0x14, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x0A, LEVEL_CASTLE_GROUNDS,   0x01,   0x0A, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x08, LEVEL_CASTLE_GROUNDS,   0x01,   0x08, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x07, LEVEL_CASTLE_GROUNDS,   0x01,   0x07, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x06, LEVEL_CASTLE_GROUNDS,   0x01,   0x06, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x05, LEVEL_VCUTM,   0x01,   0x0A, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x04, LEVEL_CASTLE_GROUNDS,   0x01,   0x04, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x03, LEVEL_CASTLE_GROUNDS,   0x01,   0x03, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x02, LEVEL_CASTLE,   0x03,   0x02, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x01, LEVEL_CASTLE,   0x01,   0x01, WARP_NO_CHECKPOINT),
		WARP_NODE( 0x00, LEVEL_CASTLE,   0x01,   0x00, WARP_NO_CHECKPOINT),
		WARP_NODE( 0xF1, LEVEL_CASTLE_GROUNDS,   0x01,   0x03, WARP_NO_CHECKPOINT),
		INSTANT_WARP(0x00, 0x02, 0, 0, 0),
		MARIO_POS(0x01, -180, -1356, 1115, 5474),
		OBJECT(MODEL_NONE, -1356, 1115, 5474, 0, -180, 0, (10 << 16), bhvAirborneWarp),
		TERRAIN(eeriegrounds_area_1_collision),
		MACRO_OBJECTS(eeriegrounds_area_1_macro_objs),
		SET_BACKGROUND_MUSIC(0x00, SEQ_LEVEL_SPOOKY),
		TERRAIN_TYPE(TERRAIN_GRASS),
		/* Fast64 begin persistent block [area commands] */
		/* Fast64 end persistent block [area commands] */
	END_AREA(),

	FREE_LEVEL_POOL(),
	MARIO_POS(0x01, -180, -1356, 1115, 5474),
	CALL(0, lvl_init_or_update),
	CALL_LOOP(1, lvl_init_or_update),
	CLEAR_LEVEL(),
	SLEEP_BEFORE_EXIT(1),
	EXIT(),
};
