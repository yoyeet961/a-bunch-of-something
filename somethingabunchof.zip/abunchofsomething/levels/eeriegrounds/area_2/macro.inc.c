const MacroObject eeriegrounds_area_2_macro_objs[] = {
	MACRO_OBJECT_END(),
};

