#include "levels/eeriegrounds/area_2/geo.inc.c"
#include "levels/eeriegrounds/area_1/geo.inc.c"
