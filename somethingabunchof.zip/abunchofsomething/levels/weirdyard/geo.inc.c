#include "levels/weirdyard/area_1/geo.inc.c"
#include "levels/weirdyard/area_2/geo.inc.c"
