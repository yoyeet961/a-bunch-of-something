const MacroObject weirdyard_area_2_macro_objs[] = {
	MACRO_OBJECT_END(),
};

