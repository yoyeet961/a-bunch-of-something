#include "levels/bob_z64/area_1/geo.inc.c"
