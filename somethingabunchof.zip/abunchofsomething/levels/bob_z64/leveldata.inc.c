#include "levels/bob_z64/area_1/collision.inc.c"
#include "levels/bob_z64/area_1/macro.inc.c"
#include "levels/bob_z64/area_1/spline.inc.c"
#include "levels/bob_z64/model.inc.c"
