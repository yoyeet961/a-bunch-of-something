const MacroObject bob_z64_area_1_macro_objs[] = {
	MACRO_OBJECT_END(),
};

