#include "levels/cch/area_1/collision.inc.c"
#include "levels/cch/area_1/macro.inc.c"
#include "levels/cch/area_1/spline.inc.c"
#include "levels/cch/model.inc.c"
