const MacroObject fake_lll_area_1_macro_objs[] = {
	MACRO_OBJECT_END(),
};

