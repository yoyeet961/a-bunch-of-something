#include "levels/fake_lll/area_1/geo.inc.c"
