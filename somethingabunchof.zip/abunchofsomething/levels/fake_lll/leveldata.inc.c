#include "levels/fake_lll/area_1/collision.inc.c"
#include "levels/fake_lll/area_1/macro.inc.c"
#include "levels/fake_lll/area_1/spline.inc.c"
#include "levels/fake_lll/model.inc.c"
